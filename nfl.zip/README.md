# NFL DRAFT

## Setup Project
1. npm install
2. npm start


![](./nfl.png)
