import React from 'react'

const Podcasts = () => {
  return (
    <div>Podcasts</div>
  )
}

export default Podcasts