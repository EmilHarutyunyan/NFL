import React from 'react'

const ProfileNav = () => {
  
  return (
    <div>ProfileNav</div>
  )
}

export default ProfileNav