import Badges from './Badges.lazy';
export default Badges;