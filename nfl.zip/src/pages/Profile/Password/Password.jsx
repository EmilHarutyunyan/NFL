import React from 'react'

const Password = () => {
  return (
    <div>Password</div>
  )
}

export default Password