import PayPalRedirect from './PayPalRedirect.lazy';
export default PayPalRedirect;