import DraftEvents from './DraftEvents.lazy';
export default DraftEvents;