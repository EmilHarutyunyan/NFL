import MultiPlayerTeam from './MultiPlayerTeam.lazy';
export default MultiPlayerTeam;