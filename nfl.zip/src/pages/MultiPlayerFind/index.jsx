import MultiPlayerFind from './MultiPlayerFind.lazy';
export default MultiPlayerFind;