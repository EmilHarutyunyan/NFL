import LiveResult from './LiveResult.lazy';
export default LiveResult;