import LiveDraft from './LiveDraft.lazy';
export default LiveDraft;