import React, { useEffect } from "react";
import PlayerItem from "../../components/PlayerItem/PlayerItem";

// Components
import { Title } from "../../components/Title/Title";
import MySelect from "../../components/MySelect/MySelect";
import Search from "../../components/Search/Search";
import Spinner from "../../components/Spinner/Spinner";
// Styles
import {
  Wrapper,
  PlayerSetting,
  SearchWrap,
  SelectWrap,
} from "./Players.styles";
import { useDispatch, useSelector } from "react-redux";
import { getPlayers, pageNav } from "../../app/features/players/playersSlice";
import { useRef } from "react";
import Pagination from "../../components/Pagination/Pagination";

const Players = () => {
  const shouldLog = useRef(true);
  const dispatch = useDispatch();
  const players = useSelector((state) => state.players);

  useEffect(() => {
    if (shouldLog.current) {
      shouldLog.current = false;
      dispatch(getPlayers());
    }
    // eslint-disable-next-line
  }, []);
  // useEffect(()=> {
  //   if(currentPage > 1) {
  //     dispatch(pageNav(currentPage))
  //   }
  //   // eslint-disable-next-line
  // },[currentPage])
  return (
    <Wrapper className="main-container">
      <Title titleText="Players list" />
      <PlayerSetting>
        <SelectWrap>
          <MySelect label={"All Positions"} />
          <MySelect label={"All teams"} />
          <MySelect label={"All Colleges"} />
        </SelectWrap>
        <SearchWrap>
          <Search />
        </SearchWrap>
      </PlayerSetting>
      {players.loading ? (
        <Spinner />
      ) : (
        <div>
          {players.results.length &&
            players.results.map((player, idx) => {
              return <PlayerItem player={player} key={idx} />;
            })}
          <Pagination
            totalCount={players.count}
            pageSize={players.limit}
            currentPage={players.currentPage}
            previous={players.previous}
            next={players.next}
            onPageChange={(page) => {
              dispatch(pageNav(page));
            }}
          />
        </div>
      )}
    </Wrapper>
  );
};

export default Players;
