import LiveBody from './LiveBody';
export default LiveBody;