import OfferTrade from './OfferTrade';
export default OfferTrade;