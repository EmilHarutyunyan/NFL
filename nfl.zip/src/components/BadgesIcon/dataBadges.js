import bpaLogo from "../../assets/img/badges/bpa.png"
import tradeDownLogo from "../../assets/img/badges/trade_down.png";
import tradeUpLogo from "../../assets/img/badges/trade_up.png"
import fanaticLogo from "../../assets/img/badges/fanatic.png";
import fanatic1Logo from "../../assets/img/badges/fanatic_1.png";
import fanatic2Logo from "../../assets/img/badges/fanatic_2.png";
import fanatic3Logo from "../../assets/img/badges/fanatic_3.png";
export const dataBadges = {
  bpa_badges: bpaLogo,
  fanatic: fanaticLogo,
  fanatic_mode_1: fanatic1Logo,
  fanatic_mode_2: fanatic2Logo,
  fanatic_mode_3: fanatic3Logo,
  trade_down: tradeDownLogo,
  trade_up: tradeUpLogo,
};