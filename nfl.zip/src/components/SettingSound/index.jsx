import SettingSound from './SettingSound';
export default SettingSound;