import React from "react";

const FlipClockZero = () => {
  return (
    <>
      <div style={{minHeight:'64px',minWidth:'151px'}}></div>
    </>
  );
};

export default FlipClockZero;
