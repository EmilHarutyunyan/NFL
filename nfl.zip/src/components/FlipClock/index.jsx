import FlipClock from './FlipClock';
export default FlipClock;