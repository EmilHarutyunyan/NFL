import LiveSettingChat from './LiveSettingChat';
export default LiveSettingChat;