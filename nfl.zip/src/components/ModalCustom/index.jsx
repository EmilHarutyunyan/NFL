import ModalCustom from './ModalCustom.lazy';
export default ModalCustom;