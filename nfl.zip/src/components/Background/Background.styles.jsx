import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  backImg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    backgroundColor:"#000"
  },
});
