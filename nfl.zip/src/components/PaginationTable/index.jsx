import PaginationTable from './PaginationTable';
export default PaginationTable;