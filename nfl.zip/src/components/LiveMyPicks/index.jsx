import LiveMyPicks from './LiveMyPicks';
export default LiveMyPicks;