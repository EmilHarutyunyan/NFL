import React from 'react'
import { ReactComponent as Searchicon } from '../../assets/svg/search.svg'
import { InputWrap } from './Search.styles'

const Search = ({placeholder="Search", icon="",handleChange}) => {
  return (
    <InputWrap>
      <label><Searchicon /></label>
      <input placeholder={placeholder}/> 
    </InputWrap>
  )
}

export default Search