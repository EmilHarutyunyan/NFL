import { createAsyncThunk, createSlice} from "@reduxjs/toolkit";
import axios from "axios";
import { API_ENDPOINT } from "../../../config/config";

const initialState = {
  loading: false,
  count: 0,
  next: null,
  previous: null,
  currentPage: 1,
  limit: 18,
  offset: 0,
  results: [],
};

export const getPlayers = createAsyncThunk(
  "players/getPlayers",
  async (_, { dispatch }) => {
    const {limit=18,offset=0} = initialState
    const res = await axios.get(
      `${API_ENDPOINT}players/?limit=${limit}&offset=${offset}`
    );
    dispatch(setPlayers(res.data));
  }
);

export const pageNav = createAsyncThunk(
  'players/pageNav',
  async (currentPage,{dispatch,getState}) => {
    const {players: {limit}} = getState()
    const offset = (currentPage - 1) * limit 

    const res = await axios.get(
      `${API_ENDPOINT}players/?limit=${limit}&offset=${offset}`
    );
    const resData = {...res.data,currentPage,offset}
    dispatch(setPlayers(resData));
  }
);

export const playersSlice = createSlice({
  name: "players",
  initialState,
  reducers: {
    setPlayers: (state, action) => {
      state.limit = action.payload?.limit || state.limit;
      state.offset = action.payload?.offset || state.offset;
      state.currentPage = action.payload?.currentPage || state.currentPage;

      state.count = action.payload.count;
      state.next = action.payload.next;
      state.previous = action.payload.previous;
      state.results = action.payload.results;
    },
  },

  extraReducers: {
    [getPlayers.fulfilled]: (state, action) => {
      state.loading = false;
    },
    [getPlayers.pending]: (state, action) => {
      state.loading = true;
    },
    [getPlayers.rejected]: (state, action) => {
      state.loading = false;
    },
    [pageNav.fulfilled]: (state, action) => {
      state.loading = false;
    },
    [pageNav.pending]: (state, action) => {
      state.loading = true;
    },
    [pageNav.rejected]: (state, action) => {
      state.loading = false;
    },
  },
});

export const { setPlayers } = playersSlice.actions;

export default playersSlice.reducer;
