// import React from 'react'
// import Switch from '@mui/material/Switch';

// const label = { inputProps: { 'aria-label': 'Switch demo' } };



// function Switch() {
//   return (
//     <Switch {...label} />
//   )
// }
// export default  Switch
