import React from 'react'

 function Range() {
  return (
    <div>Range</div>
  )
}

export default Range