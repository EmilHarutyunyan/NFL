import React from "react";



function Nums({num}) {
    return <span >{num}</span>
}
export default Nums